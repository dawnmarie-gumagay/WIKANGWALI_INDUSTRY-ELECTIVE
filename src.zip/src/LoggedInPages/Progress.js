import './PageAssets/page-styles.css'

export function Progress(){
  return <h1 >Progress</h1>
}