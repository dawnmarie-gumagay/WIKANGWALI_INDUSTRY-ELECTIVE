import './PageAssets/page-styles.css'

export function Courses(){
  return <h1>Courses</h1>
}