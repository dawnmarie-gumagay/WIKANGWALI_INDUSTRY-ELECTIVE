import './PageAssets/page-styles.css'

export function Settings(){
  return <h1>Settings</h1>
}