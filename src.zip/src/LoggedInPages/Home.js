import './PageAssets/page-styles.css'

export function Home(){
  return <h1>Home</h1>
}